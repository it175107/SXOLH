#include <stdio.h>
#include <stdlib.h>
main() {
int a,a1,b,ginomeno_p=0;
int ginomeno;
printf("give two numbers a and b : ");
scanf("%d %d",&a,&b);

ginomeno=a*b;
printf("a*b=%d\n",ginomeno);

while( b > 0) {
	if (b%2!=0)
		ginomeno_p=ginomeno_p+a;
		printf("ginomeno_p=%d\n",a);
		scanf("%d",&ginomeno_p);
}
printf("emfanise ginomeno_p\n");
system("pause");
}
