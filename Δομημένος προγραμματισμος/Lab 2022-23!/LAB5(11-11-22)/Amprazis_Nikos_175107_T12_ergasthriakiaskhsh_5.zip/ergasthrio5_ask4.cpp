#include <stdio.h>
#include <stdlib.h>
#include <math.h>
main() {
/*
MATHIMA : DOMHMENOS PROGRAMMATISMOS
TMHMA : T12
ERGASTHRIAKH ASKHSH : 5
HMEROMHNIA :11/11/2022
ONOMA :Amprazis Nikolaos
ARITHMOS MHTRWOY :175107
*/ 
int a;
double dynami=1;
int thetikoi,arnitikoi,arithmoi;

do{
    printf("Give an integer number : ");
    scanf("%d",&a);

if(a%2==0)
dynami=pow(a,2);
printf("%d^2=%lf\n",a,dynami);

else if (a%2=!0)
printf("arnitikos arithmos/n");

}
while 
printf("synolo thetikwn/n",thetikoi);
printf("synolo arnitikwn/n",arnitikoi);
printf("synolo arithmwn/n",arithmoi);

system("Pause");   
}
