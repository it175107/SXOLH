#include <stdio.h>
#include <stdlib.h>
main(){

/*
MATHIMA : DOMHMENOS PROGRAMMATISMOS
TMHMA : T12
ERGASTHRIAKH ASKHSH : 4
HMEROMHNIA :07/11/2022
ONOMA : Nikolaos Amprazis
ARITHMOS MHTRWOY :175107
*/

int eisodima;
int arithmosAkinhtwn;
double aforologitoeisodima;
double forologhteoEisodhma;
printf("give eisodima : ");
scanf("%lf",&eisodima);
printf("give arithmosAkinhtwn : ");
scanf("%d",&arithmosAkinhtwn);
forologhteoEisodhma=eisodima-aforologitoeisodima;

switch(eisodima){

case 0 : aforologitoeisodima = 12000;
	printf("aforologitoeisodima = %lf\n",aforologitoeisodima);
	break;
case 1 : aforologitoeisodima = 10000;
printf("aforologitoeisodima = %lf\n",aforologitoeisodima);
	break;
case 2 : aforologitoeisodima = 8000;
printf("aforologitoeisodima = %lf\n",aforologitoeisodima);
	break;
case 3 : aforologitoeisodima = 5000;
printf("aforologitoeisodima = %lf\n",aforologitoeisodima);
	break;
default : 
	printf("aforologitoeisodima= %lf\n",aforologitoeisodima);
	break;
}
system("pause");
}
