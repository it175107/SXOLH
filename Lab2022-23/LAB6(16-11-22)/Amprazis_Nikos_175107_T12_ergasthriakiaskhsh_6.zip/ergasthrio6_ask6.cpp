#include <stdio.h>
#include <stdlib.h>
main(){
/*
MATHIMA : DOMHMENOS PROGRAMMATISMOS
TMHMA : �12
ERGASTHRIAKH ASKHSH : 6
HMEROMHNIA : 17/11/2022
ONOMA :Nikolaos Amprazis
ARITHMOS MHTRWOY :175107
*/
int n,i=0;

do{
	printf("give an number : ");
	scanf("%d",&n);
}while(n<2 || n>100);
bool protos=true;
for (i=2;i<=(n/2);i++)

	if(n%i==0)
		bool protos=false;
	if (protos==true)
		printf("O arithmos n=%d einai protos\n",n);
	else 
		printf("o arithmos n=%d den einai protos\n",n);
system("pause");
}

